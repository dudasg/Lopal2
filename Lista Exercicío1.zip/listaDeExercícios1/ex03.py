mb = float(input("Digite o valor em MB: "))

kb = mb * 1024

print(f"{mb} MB equivalem a {kb} KB")
