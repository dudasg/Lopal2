tickets = []

for i in range(3):
    chamado = input(f"Digite o chamado {i+1}: ")
    tickets.append(chamado)

print("\nChamados cadastrados:")
for ticket in tickets:
    print(ticket)

concluido = input("\nDigite o chamado concluído: ")

if concluido in tickets:
    tickets.remove(concluido)
    print("Chamado removido!")
else:
    print("Chamado não encontrado!")

print("\nLista atualizada:")
for ticket in tickets:
    print(ticket)
