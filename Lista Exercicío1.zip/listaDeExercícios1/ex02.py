credito1 = float(input("Digite o primeiro crédito: "))
credito2 = float(input("Digite o segundo crédito: "))
#Realizando operações
soma = credito1 + credito2
subtracao = credito1 - credito2
print(f"soma: {soma}")
print(f"subtração:{subtracao}")



