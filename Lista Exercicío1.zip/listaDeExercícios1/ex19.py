quantidade_pares = 0

for i in range(1, 10):
    numero = int(input(f"Digite o número {i}º número inteiro: "))

    if numero % 2 == 0:
        quantidade_pares += 1

print(f"\nQuantidade de números pares: {quantidade_pares}")
