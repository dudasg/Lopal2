usuarios = []

while True:
    print("\n1 - Cadastrar usuário")
    print("2 - Listar usuários")
    print("3 - Sair")

    opcao = input("Escolha uma opção: ")

    if opcao == "1":
        nome = input("Digite o nome do usuário: ")
        usuarios.append(nome)

    elif opcao == "2":
        print("\nUsuários cadastrados:")

        if len(usuarios) == 0:
            print("Nenhum usuário cadastrado.")
        else:
            for usuario in usuarios:
                print(usuario)

    elif opcao == "3":
        print("Saindo do sistema...")
        break

    else:
        print("Opção inválida!")
