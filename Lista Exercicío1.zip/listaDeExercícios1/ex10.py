usuarios_cadastrados = ["allana", "carlos", "maria", "lucas"]

busca = input("Digite o nome do usuário que deseja buscar: ")

if busca in usuarios_cadastrados:
    print(f"Usuário '{busca}' encontrado no sistema!!!")
else:
    print(f"Usuário '{busca}' não encontrado.")
