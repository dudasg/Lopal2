senha = ""

while len(senha) < 8:
    senha = input("Digite uma senha com no mínimo 8 caracteres: ")

    if len(senha) < 8:
        print("Senha inválida!")
    else:
        print("Senha válida!")


