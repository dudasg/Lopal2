subtotal = 0

for i in range(1, 6):
    preco = float(input(f"Digite o preço do produto {i+1}: R$ "))
    subtotal += preco

imposto = subtotal * 0.10
valor_final = subtotal + imposto

print(f"\nSubtotal: R$ {subtotal:.2f}")
print(f"Imposto (10%): R$ {imposto:.2f}")
print(f"Valor final: R$ {valor_final:.2f}")
