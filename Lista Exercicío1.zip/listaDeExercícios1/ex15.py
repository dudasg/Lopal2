produto = input("Nome do produto: ")
quantidade_atual = int(input("Quantidade atual: "))
quantidade_vendida = int(input("Quantidade vendida: "))

estoque_restante = quantidade_atual - quantidade_vendida

print(f"\nProduto: {produto}")
print(f"Estoque restante: {estoque_restante}")

if estoque_restante < 0:
    print("ALERTA: Estoque negativo!")
