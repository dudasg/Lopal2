for i in range(1, 11):
    print(f"Deploy {i} realizado")
