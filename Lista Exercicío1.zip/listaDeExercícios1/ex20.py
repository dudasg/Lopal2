vendas = []

for i in range(5):
    valor = float(input(f"Digite o valor da venda {i+1}: R$ "))
    vendas.append(valor)

maior_venda = max(vendas)
menor_venda = min(vendas)
total_vendido = sum(vendas)
media = total_vendido / len(vendas)

print("\nRELATÓRIO DE VENDAS")
print(f"Maior venda: R$ {maior_venda:.2f}")
print(f"Menor venda: R$ {menor_venda:.2f}")
print(f"Total vendido: R$ {total_vendido:.2f}")
print(f"Média das vendas: R$ {media:.2f}")
