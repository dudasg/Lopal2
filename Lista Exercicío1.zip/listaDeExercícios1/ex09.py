desenvolvedores = [
    "Dennis",
    "Murilo",
    "Maria",
    "Paula",
    "Pedro"
]

for nome in desenvolvedores:
    print(nome)
