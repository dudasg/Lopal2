cpu = 10

while cpu <= 100:
    print(f"CPU: {cpu}%")
    cpu += 10
